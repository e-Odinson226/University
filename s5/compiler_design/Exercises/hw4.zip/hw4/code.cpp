using namespace std;
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main(){
    string stream;
    cin>>stream;
    cout<<stream;
    for (int i = 0; i < length; i++)
    {
        /* code */
    }
    

    return 0;
}
int scanner(){
    int state = 0;
    char ch;
    while (1){
        switch (state){
        case 0:
            ch = cin.get(stream,256);
            break;
        
        default:
            break;
        }
        
    }
    
    
}